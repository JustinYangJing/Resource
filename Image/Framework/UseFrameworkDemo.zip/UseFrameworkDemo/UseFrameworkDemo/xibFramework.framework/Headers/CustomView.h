//
//  CustomView.h
//  xibFramework
//
//  Created by JustinYang on 1/31/16.
//  Copyright © 2016 JustinYang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomView : UIView

@end
