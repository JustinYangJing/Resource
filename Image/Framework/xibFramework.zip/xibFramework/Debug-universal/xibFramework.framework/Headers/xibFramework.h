//
//  xibFramework.h
//  xibFramework
//
//  Created by JustinYang on 1/27/16.
//  Copyright © 2016 JustinYang. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for xibFramework.
FOUNDATION_EXPORT double xibFrameworkVersionNumber;

//! Project version string for xibFramework.
FOUNDATION_EXPORT const unsigned char xibFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <xibFramework/PublicHeader.h>


#import <xibFramework/CustomView.h>