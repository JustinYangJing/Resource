//
//  CustomView.m
//  xibFramework
//
//  Created by JustinYang on 1/31/16.
//  Copyright © 2016 JustinYang. All rights reserved.
//

#import "CustomView.h"

@implementation CustomView
-(instancetype)init{
    NSBundle *bundle = [NSBundle bundleForClass:[CustomView class]];
    self = [bundle loadNibNamed:@"CustomView" owner:[CustomView class] options:nil][0];
    return self;
}

- (IBAction)actionHandle:(id)sender {
    NSLog(@"action handle");
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
