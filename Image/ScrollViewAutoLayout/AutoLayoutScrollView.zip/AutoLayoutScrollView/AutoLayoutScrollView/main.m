//
//  main.m
//  AutoLayoutScrollView
//
//  Created by JustinYang on 12/19/15.
//  Copyright © 2015 JustinYang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
